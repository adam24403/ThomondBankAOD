import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;

public class ATMGUI {
    private JTabbedPane tabbedPane1;
    private JPanel root;
    private JTextField idTextField;
    private JRadioButton depositAccButton;
    private JRadioButton currentAccButton;
    private JButton depositButton;
    private JButton withdrawButton;
    private JButton checkBalanceButton;
    private JButton logoutButton;
    private JPanel atmPanel;
    private JPanel bankPanel;
    private JButton newAccButton;
    private JButton changeAIRButton;
    private JButton changeOverdraftLimitButton;
    private ButtonGroup accButtons;

    // Array lists to hold accounts and staff
    static ArrayList<Account> thomondAccounts = new ArrayList<>();
    static ArrayList<BankStaff> thomondStaff = new ArrayList<>();

    public ATMGUI() {
        // Hide and disable ATM buttons
        depositAccButton.setVisible(false);
        currentAccButton.setVisible(false);
        depositButton.setVisible(false);
        withdrawButton.setVisible(false);
        checkBalanceButton.setVisible(false);
        logoutButton.setVisible(false);

        depositButton.setEnabled(false);
        withdrawButton.setEnabled(false);
        checkBalanceButton.setEnabled(false);
        logoutButton.setEnabled(false);

        // Add deposit and current account radio buttons to a button group
        accButtons = new ButtonGroup();
        accButtons.add(depositAccButton);
        accButtons.add(currentAccButton);

        // Access sample accounts
        populateMyAccounts();

        // Action listener for account ID text field input
        idTextField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idInput = idTextField.getText().trim();
                // Check if ID input is empty
                if (idInput.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter an account ID.");
                    return;
                }
                int id;
                try {
                    id = Integer.parseInt(idInput);  //Converts the input to an integer
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid ID format. Please enter a number.");
                    return;
                }

                Account foundAccount = getAccountById(id);

                if (foundAccount == null) {
                    JOptionPane.showMessageDialog(null, "Account not found!");
                } else {
                    //Selects Account Type
                    if (foundAccount instanceof DepositAccount) {
                        depositAccButton.setSelected(true);
                    } else if (foundAccount instanceof CurrentAccount) {
                        currentAccButton.setSelected(true);
                    }

                    // Show and enable ATM buttons
                    depositAccButton.setVisible(true);
                    currentAccButton.setVisible(true);
                    depositButton.setVisible(true);
                    withdrawButton.setVisible(true);
                    checkBalanceButton.setVisible(true);
                    logoutButton.setVisible(true);

                    depositButton.setEnabled(true);
                    withdrawButton.setEnabled(true);
                    checkBalanceButton.setEnabled(true);
                    logoutButton.setEnabled(true);

                    tabbedPane1.setSelectedIndex(0); // Switch to the ATM user tab
                }
            }
        });

        // Action listener for the Deposit button
        depositButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String amountStr = JOptionPane.showInputDialog("Enter deposit amount:");
                if (amountStr == null || amountStr.isEmpty()) return;

                double amount;
                try {
                    amount = Double.parseDouble(amountStr);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid amount entered.");
                    return;
                }

                int id = Integer.parseInt(idTextField.getText());
                Account userAcc = getAccountById(id);
                if (userAcc != null) {
                    userAcc.deposit(amount);  // Deposit the amount into the account
                    JOptionPane.showMessageDialog(null, "Updated balance: €" + userAcc.getBalance());
                }
            }
        });

        // Action listener for the Withdraw button
        withdrawButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String amountInput = JOptionPane.showInputDialog("Enter withdrawal amount:");
                if (amountInput == null || amountInput.isEmpty()) return;

                double userAmount;
                try {
                    userAmount = Double.parseDouble(amountInput);  //Parses to double
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid amount entered.");
                    return;
                }

                int id = Integer.parseInt(idTextField.getText());
                Account acc = getAccountById(id);
                if (acc != null) {
                    acc.withdraw(userAmount);  // Withdraws from the account
                    JOptionPane.showMessageDialog(null, "Updated balance: €" + acc.getBalance());
                }
            }
        });

        // Action listener for the Check Balance button
        checkBalanceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(idTextField.getText());
                Account acc = getAccountById(id);
                if (acc != null) {
                    JOptionPane.showMessageDialog(null, "Balance: €" + acc.getBalance());
                }
            }
        });

        // Action listener for the Logout button
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Resets ATM GUI
                idTextField.setText("");
                accButtons.clearSelection();

                depositAccButton.setVisible(false);
                currentAccButton.setVisible(false);
                depositButton.setVisible(false);
                withdrawButton.setVisible(false);
                checkBalanceButton.setVisible(false);
                logoutButton.setVisible(false);

                depositAccButton.setEnabled(false);
                currentAccButton.setEnabled(false);
                depositButton.setEnabled(false);
                withdrawButton.setEnabled(false);
                checkBalanceButton.setEnabled(false);
                logoutButton.setEnabled(false);
            }
        });

        // Action listener for the New Account button
        newAccButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Options for selecting the type of account to create
                Object[] accountType = {"Deposit Account", "Current Account"};
                int choice = JOptionPane.showOptionDialog(null, "Select the account type to create:",
                        "Account Type", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                        null, accountType, accountType[0]);
                if (choice == -1) {
                    JOptionPane.showMessageDialog(null, "No account type selected.");
                    return;
                }
                // Input prompt for new user ID
                String userIdStr = JOptionPane.showInputDialog("Enter a new user ID:");
                if (userIdStr == null || userIdStr.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "User ID cannot be empty.");
                    return;
                }
                int userId;
                try {
                    userId = Integer.parseInt(userIdStr.trim());  // Parses the user ID
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid User ID. Please enter a number.");
                    return;
                }
                // Create a new account based on selected type
                if (choice == 0) {  // Deposit Account selected
                    DepositAccount newDepositAccount = new DepositAccount(userId, 0, 0, LocalDate.now());
                    thomondAccounts.add(newDepositAccount);
                    depositAccButton.setSelected(true);  // Select Deposit Account radio button
                    JOptionPane.showMessageDialog(null, "New Deposit Account created for User ID: " + userId);
                } else if (choice == 1) {  // Current Account selected
                    CurrentAccount newCurrentAccount = new CurrentAccount(userId, 0, 0, LocalDate.now(), 500); // Default overdraft limit
                    thomondAccounts.add(newCurrentAccount);
                    currentAccButton.setSelected(true);  // Select Current Account radio button
                    JOptionPane.showMessageDialog(null, "New Current Account created for User ID: " + userId);
                }
            }
        });

        // Action listener for the Change AIR button
        changeAIRButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Object[] accountOptions = {"Deposit Account", "Current Account"};
                int choice = JOptionPane.showOptionDialog(null, "Select account type to change AIR:",
                        "Change AIR", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                        null, accountOptions, accountOptions[0]);

                if (choice == -1) {
                    JOptionPane.showMessageDialog(null, "No account type selected.");
                    return;
                }

                // Input prompt for new AIR
                String newAIRStr = JOptionPane.showInputDialog("Enter new Annual Interest Rate:");
                if (newAIRStr == null || newAIRStr.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter a value");
                    return;
                }

                double newAIR;
                try {
                    newAIR = Double.parseDouble(newAIRStr.trim());
                    if (newAIR < 0) {
                        throw new NumberFormatException();
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid. Please enter a number.");
                    return;
                }
                // Set the AIR for the selected account type
                if (choice == 0) {
                    DepositAccount.setAIR(newAIR);
                    JOptionPane.showMessageDialog(null, "AIR updated to " + (newAIR * 100) + "%");
                } else if (choice == 1) {
                    CurrentAccount.setAIR(newAIR);
                    JOptionPane.showMessageDialog(null, "AIR updated to " + (newAIR * 100) + "%");
                }
            }
        });

        // Action listener for the Change Overdraft Limit button
        changeOverdraftLimitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String accountIdEntered = JOptionPane.showInputDialog("Enter Account ID:");
                // Convert the input string to an integer (Account ID)
                int accountId = Integer.parseInt(accountIdEntered);
                // Find the account by ID
                Account userAccount = getAccountById(accountId);

                if (userAccount != null) {
                    // Check if the account is a CurrentAccount
                    if (userAccount instanceof CurrentAccount) {
                        String newOverdraftLimit = JOptionPane.showInputDialog("Enter new overdraft limit:");
                        double newOverdraft = Double.parseDouble(newOverdraftLimit);
                        ((CurrentAccount) userAccount).setOverdraft(newOverdraft);
                        JOptionPane.showMessageDialog(null, "Overdraft changed successfully.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Account not found.");
                }
            }
        });
    }
    // Sample account list
    private void populateMyAccounts() {
        thomondAccounts.add(new DepositAccount(1, 1, 100, LocalDate.now()));
        thomondAccounts.add(new DepositAccount(2, 2, 500, LocalDate.now()));
        thomondAccounts.add(new DepositAccount(3, 3, 300, LocalDate.now()));
        thomondAccounts.add(new DepositAccount(4, 4, 300, LocalDate.now()));
        thomondAccounts.add(new CurrentAccount(5, 1, 0, LocalDate.now(), 100));
        thomondAccounts.add(new CurrentAccount(6, 2, 0, LocalDate.now(), 1000));
        thomondAccounts.add(new CurrentAccount(7, 4, 0, LocalDate.now(), 200));
    }

    // Finds account by ID
    private Account getAccountById(int id) {
        for (Account acc : thomondAccounts) {
            if (acc.getId() == id) {
                return acc;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("ATMGUI");
        frame.setContentPane(new ATMGUI().root);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}

