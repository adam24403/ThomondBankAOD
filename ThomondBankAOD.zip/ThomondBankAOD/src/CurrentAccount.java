import java.time.LocalDate;

public class CurrentAccount extends Account {
    static double AIR = 0.005;
    double overdraft;

    public CurrentAccount(int id, int custNo, double balance, LocalDate dateCreated, double overdraft) {
        super(id, custNo, balance, dateCreated);
        this.overdraft = overdraft;
    }

    public static double getAIR() {
        return AIR;
    }

    public static void setAIR(double newAIR) {
        AIR = newAIR;
    }

    public double getOverdraft() {
        return overdraft;
    }

    public void setOverdraft(double newOverdraft) {
        overdraft = newOverdraft;
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public void withdraw(double amount) {
        if (balance + overdraft >= amount) {
            balance -= amount;
        } else {
            System.out.println("Withdrawal exceeds overdraft limit.");
        }
    }
}



