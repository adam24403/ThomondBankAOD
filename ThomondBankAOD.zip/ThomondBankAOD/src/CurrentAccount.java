public class CurrentAccount extends Account {
    private static double AIR = 0.005;
    private double overdraft;

    public CurrentAccount(int id, int custNo, double overdraft) {
        super(id, custNo);
        this.overdraft = overdraft;
    }

    @Override
    public boolean withdraw(double amount) {
        if (amount > 0 && (balance + overdraft) >= amount) {
            balance -= amount;
            return true;
        }
        return false;
    }

    public static void setAIR(double newAIR) {
        AIR = newAIR;
    }

    public static double getAIR() {
        return AIR;
    }

    public double getOverdraft() { return overdraft; }
    public void setOverdraft(double overdraft) { this.overdraft = overdraft; }
}
