import java.time.LocalDate;

public class DepositAccount extends Account {
    static double AIR = 0.02;

    public DepositAccount(int id, int custNo, double balance, LocalDate dateCreated) {
        super(id, custNo, balance, dateCreated);
    }

    public static double getAIR() {
        return AIR;
    }

    public static void setAIR(double newAIR) {
        AIR = newAIR;
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
        } else {
            System.out.println("Insufficient funds.");
        }
    }
}


