import java.time.LocalDate;

public class CurrentAccount extends Account {
     double AIR = 0.005;
     double overdraft;

    public CurrentAccount(int id, int custNo, double balance, LocalDate dateCreated, double AIR, double overdraft) {
        super(id, custNo, balance, dateCreated);
        this.AIR = AIR;
        this.overdraft = overdraft;
    }
}


