import java.time.LocalDate;

public class DepositAccount extends Account {
    double AIR = 0.02;

    public DepositAccount(int id, int custNo, double balance, LocalDate dateCreated, double AIR) {
        super(id, custNo, balance, dateCreated);
        this.AIR = AIR;
    }

    public double getAIR() {
        return AIR;
    }

    public void setAIR(double AIR) {
        this.AIR = AIR;
    }
}


